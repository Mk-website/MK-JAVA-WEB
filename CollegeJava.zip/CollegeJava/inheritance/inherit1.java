class a1
{ 
int x;
void display()
{
System.out.println(x);
}
}
class b1 extends a1
{
void disp()
{
   x=6;
}
}
class  in1
{
public static void main(String st[])
{
 new b1().disp();
new b1().display();
}
}
