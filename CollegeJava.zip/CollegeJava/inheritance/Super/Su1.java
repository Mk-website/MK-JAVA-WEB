class Su
{
int Roll;
String Name;
}
class sub extends {
String Roll = "4298/22";
void display()
{
 super.Roll = 4298;

Name = "Manjit";
System.out.println("Roll No : "+ Roll +"\nName :" +Name+"\nRoll No :"+super.Roll+"Name :"+Name);

}
}
class Su1main{
public static void main(String[] st)
{
sub obj = new sub();
obj.display();
}
}
