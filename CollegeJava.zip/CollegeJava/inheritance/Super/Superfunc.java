class Su2{
int r;
String name;
Su2(int r)
{
System.out.println("Roll no :"+r);
}
}
class su3 extends Su2{



su3(){
super(1);
}
}

class Main{
public static void main(String st[]){
su3 obj = new su3();
}}

