class student
{
void display();
}

