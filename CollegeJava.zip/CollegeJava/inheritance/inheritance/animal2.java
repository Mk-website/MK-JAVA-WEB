package animal2;
/*
 Write a Java program to create a class called 
Animal with a method named move(). 
Create a subclass called Cheetah that overrides
 the move() method to run
*/
class Animal
	{
	void move()
	{
	System.out.println("Move");
	}
	}
class Cheetah extends Animal
	{
	void move()
	{
	System.out.println("Cheetah Run");
	}
	}
class Main
	{
	public static void main(String st[])
	{
	Animal a=new Animal();
	a.move();
	Cheetah c = new Cheetah();
	c.move();
	}
	}
