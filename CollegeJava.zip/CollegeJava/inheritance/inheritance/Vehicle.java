package vehicle;
/*
Write a Java program to create a class called Vehicle
 with a method called drive(). 
Create a subclass called Car that overrides the drive() 
method to print "Repairing a car".
*/
class Vehicle
	{
	void drive()
	{
	System.out.println("Drive Vehicle");
	}
	}
	class Car extends Vehicle
	{
	void drive()
	{
	System.out.println("Repairing Car");
	}
	}
	class Main
	{
	public static void main(String st[])
	{
	Vehicle vehicle=new Vehicle();
	vehicle.drive();
	Vehicle car = new Car();
	car.drive();
	}
	}
