package shape;
/*
Write a Java program to create a class called Shape 
with a method called getArea(). 
Create a subclass called Rectangle 
that overrides the getArea() method to calculate 
the area of a rectangle.
*/
class Shape
	{
	double getArea()
	{
	System.out.println("Calculate Area");
	return 0;
	}
	}
	class Rectangle extends Shape
	{
	private double length;
	private double width;
	Rectangle(double l,double w)
	{
	length=l;
	width=w;
	}
	double getArea()
	{
	return length*width;
	}
	}
	class  Main
	{
	public static void main(String st[])
	{
	Shape rectangle=new Rectangle(4.0,5.0);
	double area = rectangle.getArea();
	System.out.println(area);
	}
	}
