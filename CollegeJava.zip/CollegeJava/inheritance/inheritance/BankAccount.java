package bankaccount;
/*
Write a Java program to create a class 
known as "BankAccount" with methods called deposit() 
and withdraw(). 
Create a subclass called SavingsAccount 
that overrides the withdraw() method to prevent 
withdrawals 
if the account balance falls below one hundred.
*/
class BankAccount
	{
	private double balance;
	public BankAccount(double balance)
	{
	this.balance=balance;
	}
	public void deposit(double amount)
	{
	balance+=amount;
	System.out.println("Deposited : "+amount);
	}
	public void withdraw(double amount)
	{
	balance-=amount;
	System.out.println("Withdrawn : "+amount);
	}
	public double getBalance()
	{
	return balance;
	}
	}
class SavingsAccount extends BankAccount
	{
	public  SavingsAccount(double balance)
	{
	super(balance);
	}
	public void withdraw(double amount)
	{
	if(getBalance()-amount < 100)
	{
	
	System.out.println("Withdrawal not Allowed.");
	}
	else
	{
	super.withdraw(amount);
	}
	}
	}
class Main
	{
	public static void main(String st[])
	{
	BankAccount acc=new BankAccount(1000);
	acc.deposit(500);
	acc.withdraw(300);
	System.out.println("Balance : "+acc.getBalance());
	SavingsAccount savingsAccount = new SavingsAccount(1000);
        savingsAccount.deposit(500);
        savingsAccount.withdraw(1430);
	savingsAccount.withdraw(199);
        System.out.println("Balance : "+savingsAccount.getBalance());
	}
	}

/*

// BankAccount class
class BankAccount {
    private double balance;

    public BankAccount(double balance) {
        this.balance = balance;
    }

    public void deposit(double amount) {
        balance += amount;
        System.out.println("Deposited: " + amount);
    }

    public void withdraw(double amount) {
        balance -= amount;
        System.out.println("Withdrawn: " + amount);
    }

    public double getBalance() {
        return balance;
    }
}

// SavingsAccount subclass that overrides the withdraw() method
class SavingsAccount extends BankAccount {
    public SavingsAccount(double balance) {
        super(balance);
    }

    @Override
    public void withdraw(double amount) {
        if (getBalance() - amount < 100) {
            System.out.println("Withdrawal not allowed. Balance will fall below $100.");
        } else {
            super.withdraw(amount);
        }
    }
}

 class Main {
    public static void main(String[] args) {
        BankAccount account = new BankAccount(1000);
        account.deposit(500);
        account.withdraw(200);
        System.out.println("Balance: " + account.getBalance());

        SavingsAccount savingsAccount = new SavingsAccount(1000);
        savingsAccount.deposit(500);
        savingsAccount.withdraw(200);
        savingsAccount.withdraw(1300); // Withdrawal not allowed
        System.out.println("Balance: " + savingsAccount.getBalance());
    }
}
*/
