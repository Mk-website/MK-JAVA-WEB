package duplicate;
/*Here is a Java program that prints the duplicate elements of an array:
*/
 class Duplicate {
    public static void main(String[] args) {
        int[] array = {1, 2, 2, 3, 3, 3, 4, 4, 4, 4};

        System.out.println("Duplicate elements:");
        for (int i = 0; i < array.length; i++) {
            int count = 0;
            for (int j = 0; j < array.length; j++) {
                if (array[i] == array[j]) {
                    count++;
                }
            }
            if (count > 1 && array[i] != -1) {
                System.out.println(array[i]);
                array[i] = -1;
            }
        }
    }
}
