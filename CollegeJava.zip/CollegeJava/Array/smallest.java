package smallest;
class Smallest
        {
        public static void main(String st[])
        {
        int arr[]={1,20,30,4,5},i,temp,min=0;
        temp=arr[0];
        for(i=0;i<arr.length;i++)
        {
        if(arr[i]<temp)
        {
        temp=arr[i];
        min=temp;
        }
        else
        {
        min=temp;
        }
        }
        System.out.println("Smallest element is :- "+min);

        }
        }
