package copyarray;
class CopyArray
	{
	public static void main(String st[])
	{
	int arr[]={1,2,3,4},i;
	int arr2[] = new int[arr.length];
	for(i=0;i<arr.length;i++)
	{
	arr2[i]=arr[i];
	}
	System.out.println("Orignel Array");
	for(i=0;i<arr.length;i++)
	{
	System.out.println(arr[i]);
	}
	System.out.println("Copy Array");
        for(i=0;i<arr.length;i++)
        {
        System.out.println(arr2[i]);
        }
	}
	}
