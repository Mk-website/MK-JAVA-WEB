package sumofelements;
class SumOfElements
	{
	public static void main(String st[])
	{
	int arr[]={1,2,3,4},sum=0,i;
	for(i=0;i<arr.length;i++)
	{
	sum+=arr[i];
	}
	System.out.println("Sum Of Element :- "+sum);
	}
	}
