package largest;
class Largest
	{
	public static void main(String st[])
	{
	int arr[]={1,20,30,4,5},i,temp,max=0;
	temp=arr[0];
	for(i=0;i<arr.length;i++)
	{
	if(arr[i]>temp)
	{
	temp=arr[i];
	max=temp;
	}
	else
	{
	max=temp;
	}
	}
	System.out.println("Largest element is :- "+max);
	
	}
	}
