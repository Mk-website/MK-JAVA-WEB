package leftrotate;
/*
Program to left rotate the elements of an array
*/

class LeftRotate {
    public static void main(String[] args) {
        int[] array = {1, 2, 3, 4, 5};
        int rotations = 2;

        System.out.println("Original array:");
        for (int num : array) {
            System.out.print(num + " ");
        }
        System.out.println();

        // Left rotate
        for (int i = 0; i < rotations; i++) {
            int temp = array[0];
            for (int j = 0; j < array.length - 1; j++) {
                array[j] = array[j + 1];
            }
            array[array.length - 1] = temp;
        }

        System.out.println("Rotated array:");
        for (int num : array) {
            System.out.print(num + " ");
        }
        System.out.println();
    }
}
