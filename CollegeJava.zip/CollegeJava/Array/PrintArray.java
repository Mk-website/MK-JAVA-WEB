package printarray;
class PrintArray
	{
	public static void main(String st[])
	{
	int arr[]={1,2,3,4},i;
	for(i=0;i<arr.length;i++)
	{
	System.out.println(arr[i]);
	}
	}
	}
