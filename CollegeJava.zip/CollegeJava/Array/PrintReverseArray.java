package printreversearray;
class PrintReverseArray
        {
        public static void main(String st[])
        {
        int arr[]={1,2,3,4},i;
        for(i=arr.length-1;i>0;i--)
        {
        System.out.println(arr[i]);
        }
        }
        }
