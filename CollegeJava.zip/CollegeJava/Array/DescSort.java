package descsort;
class DescSort
        {
        public static void main(String st[])
        {
        int arr[]={4,3,5,1,6},i,j,temp;
        for(i=0;i<arr.length;i++)
        {
        for(j=i+1;j<arr.length;j++)
        {
        if(arr[j]<arr[i])
        {
        temp=arr[j];
        arr[j]=arr[i];
        arr[i]=temp;
        }
        }
        }
	for(i=0;i<arr.length;i++)
	{
	System.out.println(arr[i]);
	}
        }
        }
