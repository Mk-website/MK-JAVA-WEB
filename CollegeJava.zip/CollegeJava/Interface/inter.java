interface inter1{
void display();
}
class A implements inter1
{
public void display()
{
System.out.println("Display");
}
}
class B {
public static void main(String[] st)
{
 inter1 obj = new A();
obj.display();
}
}

