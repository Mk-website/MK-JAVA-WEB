class matrix
{

	public static void main(String args[])
	{
	      int matrixA[][]={{1,2,3,},{3,4,5}};
	      int matrixB[][]={{5,6,7},{7,8,9,}};
              int matrixSUM[][]= new int[2][3];
              for(int i=0;i<2;i++)
              {
                   for(int j=0;j<3;j++)
                   {
			matrixSUM[i][j]=matrixA[i][j]+matrixB[i][j];
                   }
              }
            System.out.println("the sum of two matrices are:");
               for(int i=0;i<2;i++)
	       {
			for(int j=0;j<3;j++)
			{
                           if(matrixSUM[i][j] >10)
				{
				System.out.print(" | "+matrixSUM[i][j]);
				}
				System.out.print("  | " + martixSUM[i][j]);

			}
				System.out.println();
	       }
         }
}
