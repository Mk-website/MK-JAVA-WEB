package P1;
class A
{}
class B{}
class C{

public static void main(String st[])
{
System.out.println("hello");
}
}