
class base{
int x;
x=5;
}
class child extends base{
x=6;
public static void main(String[] args)
{
child ob = new child();
ob.x=90;
}
}
