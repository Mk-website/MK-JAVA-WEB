package deepcopy;

 class DeepCopy {
    public static void main(String[] args) {
        String original = "Hello";
        StringBuffer sb = new StringBuffer(original);
        String copy = sb.toString();

        System.out.println("Original: " + original);
        System.out.println("Copy: " + copy);

        // Modify the original string
        original = "World";

        System.out.println("After modification:");
        System.out.println("Original: " + original);
        System.out.println("Copy: " + copy);
    }
}
