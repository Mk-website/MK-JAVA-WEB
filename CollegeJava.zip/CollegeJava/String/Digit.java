package digit;

class Digit
	{
	public static void main(String st[])
	{
	String str="r768";
	boolean isDigit=false;
	int i;
	for(i=0;i<str.length();i++)
	{
	if(str.charAt(i) > '0' && str.charAt(i) < '9')
	{
	isDigit=true;
	}
	else{
	isDigit=false;
	break;
	}
	}
	if(isDigit)
	{
	System.out.println("Only digit");
	}
	else
	{
	System.out.println("Mix");
	}
	}
	}
