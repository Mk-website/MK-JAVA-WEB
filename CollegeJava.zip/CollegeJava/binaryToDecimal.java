package binaryToDecimal;
class  BinaryToDecimal
		{
		public static void main(String st[])
		{
		byte binary[] = {0,0,1,1};
		int decimal=0,power =0,i=0;
		for(i=binary.length-1;i>=0;i--)
		{
		 if(binary[i]==1)
		{
		decimal +=Math.pow(2,power);
		}
		power++;
		}
		System.out.println("Decimal number is :"+decimal);
		}
		}




