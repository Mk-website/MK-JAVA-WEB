package countstring;
class CountString
		{
		private int count_latter;
		private int count_space;
		private int count_number;
		private int count_character;

		void count(String str)
		{ int i;
		if(str=="")
		{
		System.out.println("Empty String");
		}
		else 
		{
		count_number++;
		for(i=0;i<str.length();i++) 
		{
		 if(i==0 && str.charAt(i)!=' ')
			{
			count_latter++;
			} 
		else if(str.charAt(i)==' ')
			{
			count_space++;
			if(str.charAt(i+1)!=' ' && str.charAt(i+1)!=' ')
			{
			 count_latter++;
			}
			}
		else if(str.charAt(i)=='\n')
			{
			count_number++;
			if(str.charAt(i+1)!=' ' && str.charAt(i+1)!=' ')
			{
			 count_latter++;
			}
			}
		count_character++;
		}
		}
		}
		
		void display()
		{
		System.out.println("No. of latters :-"+count_latter+"\nNo of Character :- "+count_character+"\nNo of Space :-"+count_space+"\nNo of Line :-"+count_number);
		}
		
		public static void main(String st[])
		{
		CountString obj = new CountString();
		String sentance = "";
		obj.count(sentance);
		obj.display();
		}
		}
