package areaofrectangle;
class AreaOfRectangle
		{
		public static void main(String st[])
		{
		float l=12f,b=5f,area;
		area = l*b;
		System.out.println("Area of Rectangle is :- "+area);
		}
		}
