package compare;
class Compare
	{
	public static void main(String st[])
	{
	int a=12,b=56;
	if(a==b)
	System.out.println("Number are equel");
	else
	System.out.println("Number are Not equel");
	}
	}
