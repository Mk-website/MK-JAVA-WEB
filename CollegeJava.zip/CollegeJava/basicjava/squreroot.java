package squreroot;
class Squreroot	
	{
	public static void main(String st[])
	{
	double num=36,squreroot;
	squreroot=Math.sqrt(num);
	System.out.println("Squreroot of "+num+ " is "+squreroot);
	}
	}
