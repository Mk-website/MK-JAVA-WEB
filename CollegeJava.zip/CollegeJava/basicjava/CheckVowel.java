package checkvowel;
class CheckVowel
	{
	public static void main(String st[])
	{
	char ch = 'A';
	if(ch=='a' || ch=='o' || ch=='i' || ch=='e' || ch=='u' || ch=='A' || ch=='E' || ch=='I' || ch == 'O' || ch=='U')
	{
	System.out.println(ch+" is Vowel ");
	}
	else 
	{
	System.out.println(ch+" is Consonant");
	}
	}
	}

