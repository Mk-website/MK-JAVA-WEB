package electricitybill;
class ElectricityBill
		{
		public static void main(String st[])
		{
		float prevReading =100,curReading=200,unit=6,eleBill;
		eleBill=(curReading-prevReading)*unit;
		System.out.println("Your Electricity Bill is "+eleBill);
		}
		}
