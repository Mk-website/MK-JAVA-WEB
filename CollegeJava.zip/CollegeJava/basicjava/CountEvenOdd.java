package countevenodd;
class CountEvenOdd
	{
	public static void main(String st[])
	{
	int arr[] = {1,2,3,4,5,6},i,even=0,odd=0;
	for(i=0;i<arr.length-1;i++)
	{
	if(arr[i]%2==0)
	{
	even++;
	}
	else
	{
	odd++;
	}
	}
	System.out.println("No of Even elements :"+even+"\nNo of Odd elements:"+odd);
	}
	}
