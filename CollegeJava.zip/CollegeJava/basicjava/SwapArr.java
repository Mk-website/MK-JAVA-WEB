package swaparr;
class SwapArr
	{
	public static void main(String st[])
	{
	int arr[] = {1,2,3,4},i;
	int arr1[] = new int[arr.length];
	for(i=0;i<arr.length;i++)
	{
	if(i==0)
	{
	arr1[i]=arr[arr.length-1];
	}
	else if(i==arr.length-1)
	{
	arr1[i]=arr[0];
	}
	else 
	{
	arr1[i]=arr[i];
	}
	}
	for(i=0;i<arr1.length;i++)
	{
	 System.out.print(arr[i]);
	}
	System.out.println();
	for(i=0;i<arr1.length;i++)
        {
         System.out.print(arr1[i]);
        }
	System.out.println();
	}
	}
