package stringtoint;
class StringToInt
	{
	public static void main(String st[])
	{
	String num = "1234";
	int number=0,sign =1;
	for(int i=0;i<num.length();i++)
	{
	char c = num.charAt(i);
	if(i==0 && c =='-')
	{
	 sign = -1;
	 
	}
	else if(c >='0' && c <= '9')
	{
	number=number * 10 +(c-'0');
	
	}
	else 
	{
	System.out.println("Error");
	}
	}
		System.out.println(number*sign);
	}
	}
	
