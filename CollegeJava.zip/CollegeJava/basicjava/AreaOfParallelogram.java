package areaofparallelogram;
class AreaOfParallelogram
 		{
 		public static void main(String st[])
 		{
 		float base=10,heigth=5,area;
 		area = base*heigth;
 		System.out.println("Area of Parallelogram :- "+area);
 		}
 		}
