package areaofeqtriangle;
class AreaOfEqTriangle
		{
		public static void main(String st[])
		{
		double a=4,area;
		area = (Math.sqrt(3)/4)*a*a;
		System.out.println("Area of Eq Triangle is :- "+area);
		}
		}

