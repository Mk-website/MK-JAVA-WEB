package areaofcircle;
class AreaOfCircle
	{
	public static void main(String st[])
	{
	final float PI = 3.14f;
	float r = 7f,area;
	area = PI*r*r;
	System.out.println("Area of Circle is : "+area);
	}
	}
