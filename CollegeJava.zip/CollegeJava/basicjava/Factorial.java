package factorial;
class Factorial
	{
	public static void main(String st[])
	{
	int i=0,num=5,fact=1;
	for(i=num;i>0;i--)
	{
	fact *=i;
	}
	System.out.println("Factorial of " +num+" is "+fact);
	}
	}
