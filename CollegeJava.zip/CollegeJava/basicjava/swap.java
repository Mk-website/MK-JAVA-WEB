package swap;
class swap
{
public static void main(String[] st)
{
 int a = 45,b=50;
 int c;
 c = a+b;
 a = c-b;
 b= c-a;
System.out.println("a = "+a+" b = "+b);
}
}
