package avgmarks;
class AvgMarks
	{
	public static void main(String st[])
	{
	float s1=60,s2=70,s3=65,s4=50,s5=80,n=5,avgmarks;
	avgmarks=(s1+s2+s3+s4+s5)/n;
	System.out.println("Average of Marks is : "+avgmarks);
	}
	}
	
