package sumprimenum;
class SumPrimeNum
	{
	public static void main(String st[])
	{
	int num,sum=0,isPrime;
	for(num=2;num<=100;num++)
	{
	isPrime=1;
	for(int i = 2; i<=num/2;i++)
	{
	if(num%i==0)
	{
	isPrime =0;
	break;
	}
	}
	if(isPrime==1)
	{
		sum+=num;
	}
	}
	System.out.println(sum);
	}
	}
