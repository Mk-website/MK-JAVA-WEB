package areaofrhombus;
class AreaOfRhombus
	{
	public static void main(String st[])
	{
	float d1=10,d2=15,area;
	area=(d1*d2)/2;
	System.out.println("Area of Rhombus is :- "+area);
	}
	}
