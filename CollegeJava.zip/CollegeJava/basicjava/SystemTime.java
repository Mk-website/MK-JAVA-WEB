package systemtime;
class SystemTime extends java.util.Date
	{
	public static void main(String st[])
	{
	SystemTime obj = new SystemTime();
	int hh=obj.getHours();
	System.out.println(hh);
	}
	}

