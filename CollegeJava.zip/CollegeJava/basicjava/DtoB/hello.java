class hello
	{
	public static void main(String st[])
	{
		System.out.println("Hello World");
	}
	}
