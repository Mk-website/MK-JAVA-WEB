package avg;
class avg
	{
public static void main(String[] st)
	{
	 int a=56,b=90,c=45,d=86,e=78,avg;
	 avg = (a+b+c+d+e)/5;
	 System.out.println(avg);
	}
	}

