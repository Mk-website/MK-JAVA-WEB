package convertsecondtohhmmss;
class ConvertSecondToHhMmSs
		{
		public static void main(String st[])
		{
		int sec =3600,hh,mm,ss,temp;
		hh=sec/3600;
		temp=sec%3600;
		mm=temp/60;
		ss=temp%60;
		System.out.println(hh+":"+mm+":"+ss);
		}
		}
