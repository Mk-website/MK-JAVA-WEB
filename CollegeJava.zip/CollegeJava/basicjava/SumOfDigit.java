package sumofdigit;
class SumOfDigit
		{
		public static void main(String st[])
		{
		int digit=5447,sum=0,rem;
		while(digit>0)
		{
		rem=digit%10;
		sum+=rem;
		digit/=10;
		}
		System.out.println("Sum of digit "+sum);
		}
		}
