package computen;
class ComputeN
	{
	public static void main(String st[])
	{
	int n = 2;
	int N = n+(n*n)+(n*n*n);
	System.out.println("Value of (n+(nn)+(nnn)) :- "+N);
	}
	}
