package areaoftriangle;
class AreaOfTriangle
		{
		public static void main(String st[])
		{
		double a=6,b=4,c=8,s,area;
		s=(a+b+c)/2;
		area=Math.sqrt(s*(s-a)*(s-b)*(s-c));
		System.out.println("Area of Triangle is :- "+area);
		}
		}
