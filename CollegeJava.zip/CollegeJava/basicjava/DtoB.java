package DtoB;
class DtoB
	{
	public static void main(String[] st)
	{
	int Decimal=12,i=0;
	String Binary="";
	while(Decimal>0)
			{
			Binary=Decimal%2+Binary;
			Decimal/=2;
			}
			 System.out.println(Binary);
	}
	}

