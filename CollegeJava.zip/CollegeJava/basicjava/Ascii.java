package ascii;
class Ascii
	{
	public static void main(String st[])
	{
	char character = 'A';
        int asciiValue = character;
        System.out.println("ASCII value of " + character+" is " + asciiValue);
        }
        }
