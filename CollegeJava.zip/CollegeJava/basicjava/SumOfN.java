package sumofn;
class SumOfN
	{
	public static void main(String st[])
	{
	int n=10,s,a=1,d=1;
	s=(n/2)*(2*a+(n-1)*d);
	System.out.println("Sum of "+n+" no. is "+s);
	}
	} 
