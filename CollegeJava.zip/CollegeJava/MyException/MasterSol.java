package mastersol;
class MasterSol
        {
        public static void main(String st[])
        {
        try{
        int x=Integer.parseInt(st[0]);
        int y=Integer.parseInt(st[1]);
        System.out.println(x+y);
        }
        catch (Exception e)
        {
        System.out.println("Your Error is "+e.getMessage());
        }
        
        }
        }
