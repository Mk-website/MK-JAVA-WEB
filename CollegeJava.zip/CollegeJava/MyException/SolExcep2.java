package solexcep2;
class SolExcep2
        {
        public static void main(String st[])
        {
        try{
        int x=Integer.parseInt(st[0]);
        int y=Integer.parseInt(st[1]);
        System.out.println(x+y);
        }
        catch (NumberFormatException e)
        {
        System.out.println("Kindly enter integer");
        }
        catch (ArrayIndexOutOfBoundsException e)
        {
        System.out.println("kindly enter 2 argument");
        }
        }
        }
