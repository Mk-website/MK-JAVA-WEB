package solexcep1;
class  SolExcep1
        {
        public static void main(String st[])
        {
        try{
        System.out.println(st[0]);
        }
        catch (ArrayIndexOutOfBoundsException e)
        {
        System.out.println("kindly please give some argument");
        }
        }
        }
