package excep1;
class Excep1
	{
	public static void main(String st[])
	{
	System.out.println(st[0]);
	}
	}
