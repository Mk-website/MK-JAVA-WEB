class st {
private int rollno;
private String name;
void setR(int r)
{
rollno =r;
}
int getR(){
return rollno;
}
void setN(String n){
name = n;
}
String getN(){
return name;
}
}
class JavaMain
{
public static void main(String[] args)
{
st ob = new st();
ob.setR(56);
ob.setN("Manjit");
int r = ob.getR();
String n = ob.getN();
System.out.println("Roll no :- "+r+"\n Name :- "+n);
}
}
